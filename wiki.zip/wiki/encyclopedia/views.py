from django.shortcuts import render
from encyclopedia.util import get_entry, list_entries, save_entry
from bs4 import BeautifulSoup
from markdown import markdown
import re
from . import util
from django import forms
import random

class NewSearchForm(forms.Form):
    search = forms.CharField(label="Search Encyclopedia")
    
class NewCreateForm(forms.Form):
    title = forms.CharField(label="Title")
    content = forms.CharField(widget=forms.Textarea(attrs={'rows':10, 'cols':100}))
    
class NewEditForm(forms.Form):
    title = forms.CharField(label="Title")
    content = forms.CharField(widget=forms.Textarea(attrs={'rows':10, 'cols':100}))
    
def index(request):
    contains_search_substring = []
    if request.method == "POST":
        form = NewSearchForm(request.POST)
        if form.is_valid():
            search = form.cleaned_data["search"]
            if search in list_entries():
                return wiki(request, search)
            else:
                for entry in util.list_entries():
                    if search in entry:
                        contains_search_substring.append(entry)
                return render(request, "encyclopedia/search_error.html", {
                    "entries": contains_search_substring,
                    "form": NewSearchForm()
                })
        else:
            return render(request, "encyclopedia/index.html", {
                "entries": util.list_entries(),
                "form": form
            })
                
    
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries(),
        "form": NewSearchForm()
    })
    
def create(request):
    if request.method == "POST":
        form = NewCreateForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data["title"]
            content = form.cleaned_data["content"]
            if title not in util.list_entries():
                save_entry(title, content)
                return wiki(request, title)
            else:
                return render(request, "encyclopedia/create_error.html", {
                "form": form
            }) 
        else:
            return render(request, "encyclopedia/create.html", {
                "form": form
            })
 
    return render(request, "encyclopedia/create.html", {
        "form": NewCreateForm()
    })
    
def random_choice(request):

    return wiki(request, random.choice(list_entries()))


def wiki(request, title):
    if title in util.list_entries():

        # md -> html -> text since BeautifulSoup can extract text cleanly
        html = markdown(get_entry(title))

        # remove code snippets
        html = re.sub(r'<pre>(.*?)</pre>', ' ', html)
        html = re.sub(r'<code>(.*?)</code >', ' ', html)
        html = re.sub(r'<h.*(.*?)</h.*>',string=html,repl="")

        # extract text
        soup = BeautifulSoup(html, "html.parser")
        text = ''.join(soup.findAll(text=True))

        return render(request, "encyclopedia/wiki.html", {
        "title": title, 
        "entry": text
        })
    else:
        return render(request, "encyclopedia/search_error.html")
    
def edit(request):
    if request.method == "GET":
        form = NewEditForm(request.GET)
        if form.is_valid():
            title = form.cleaned_data["title"]
            content = form.cleaned_data["content"]
        else:
            return render(request, "encyclopedia/edit.html", {
                "form": form
            })
    return render(request, "encyclopedia/edit.html", {
        "form": NewEditForm(request.GET)
    })
    